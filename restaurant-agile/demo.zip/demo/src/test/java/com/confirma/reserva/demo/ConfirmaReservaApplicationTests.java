package com.confirma.reserva.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfirmaReservaApplicationTests {

	@Test
	void contextLoads() {
	}

}
